window.addEventListener("load",init);

function init(){
    
        var masonry = new MiniMasonry({
            container: document.getElementById('masonry'),
            gutter: 10,
            basewidth: 350
        }); 
}
